
GT7 Parking Demo
================
Versión mejorada centrada en mostrar los 4 coches en un parking y controles mejorados.
Controles:
- Flecha Arriba: acelerar hacia delante
- Flecha Abajo: frenar si vas hacia delante; si estás parado, ir marcha atrás
- Flecha Izquierda/Derecha: girar
- Space: freno de mano
- Botón 'Colocar coche en parking': coloca el coche seleccionado como coche jugable

Para usar: descomprime y abre index.html en Chrome.
