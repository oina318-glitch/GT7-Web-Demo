
// Parking demo - improved car shapes and control mapping
let scene, camera, renderer, clock;
let player, cars = [];
let hud;
let keyState = {};
let inited=false;

initUI();

function initUI(){
  document.getElementById('spawnBtn').onclick = ()=>{
    if(!inited){
      start();
      inited = true;
    } else {
      spawnPlayerCar();
    }
  };
  document.getElementById('resetBtn').onclick = ()=>{ resetPlayer(); };
}

function start(){
  init();
  animate();
}

function init(){
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x708090);
  clock = new THREE.Clock();
  camera = new THREE.PerspectiveCamera(60, window.innerWidth/window.innerHeight, 0.1, 1000);
  renderer = new THREE.WebGLRenderer({antialias:true});
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const amb = new THREE.AmbientLight(0xffffff, 0.8); scene.add(amb);
  const dir = new THREE.DirectionalLight(0xffffff, 0.6); dir.position.set(5,10,7); scene.add(dir);

  // Ground / parking lot
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(400,200), new THREE.MeshStandardMaterial({color:0x222222}));
  ground.rotation.x = -Math.PI/2; scene.add(ground);

  // parking lines
  const lineMat = new THREE.LineBasicMaterial({color:0xffffff});
  for(let i=0;i<6;i++){
    const geom = new THREE.BufferGeometry().setFromPoints([ new THREE.Vector3(-60 + i*24, 0.02, -10), new THREE.Vector3(-60 + i*24, 0.02, 80) ]);
    const line = new THREE.Line(geom, lineMat); scene.add(line);
  }

  // simple environment boxes
  const boxMat = new THREE.MeshStandardMaterial({color:0x445566});
  for(let i=0;i<8;i++){ let b = new THREE.Mesh(new THREE.BoxGeometry(6,8,6), boxMat); b.position.set(-180 + i*50,4, -120); scene.add(b); }

  // spawn other parked cars (visual)
  cars = [];
  cars.push(makeCarMesh(0x2222ff,"GTR")); cars.push(makeCarMesh(0x22aa22,"R8"));
  cars.push(makeCarMesh(0xffaa00,"Supra")); cars.push(makeCarMesh(0x44ff44,"Porsche"));
  cars[0].position.set(-36,0.35,12); cars[1].position.set(-12,0.35,12); cars[2].position.set(12,0.35,12); cars[3].position.set(36,0.35,12);
  for(let c of cars) scene.add(c);

  // spawn player car
  spawnPlayerCar();

  window.addEventListener('resize', onWindowResize);
  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);

  hud = {speed: document.getElementById('speed'), tire: document.getElementById('tire'), status: document.getElementById('status')};
  document.getElementById('hud').style.display = 'block';
  // initial camera
  camera.position.set(0,8,20); camera.lookAt(0,0,0);
}

function makeCarMesh(color, name){
  const g = new THREE.Group();
  // body
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.4,0.6,4.4), new THREE.MeshStandardMaterial({color: color}));
  body.position.y = 0.45; g.add(body);
  // cabin
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.6,0.5,1.6), new THREE.MeshStandardMaterial({color:0x111111}));
  cabin.position.set(0,0.85,-0.1); g.add(cabin);
  // wheels (simple)
  const wheelMat = new THREE.MeshStandardMaterial({color:0x111111});
  const wheelGeo = new THREE.CylinderGeometry(0.35,0.35,0.4,8);
  const w1 = new THREE.Mesh(wheelGeo, wheelMat); w1.rotation.z = Math.PI/2; w1.position.set(1.05,0.2,1.6); g.add(w1);
  const w2 = w1.clone(); w2.position.set(-1.05,0.2,1.6); g.add(w2);
  const w3 = w1.clone(); w3.position.set(1.05,0.2,-1.6); g.add(w3);
  const w4 = w1.clone(); w4.position.set(-1.05,0.2,-1.6); g.add(w4);
  g.userData = {speed:0,dir:0, name: name, damage:0, tire:"Slick"};
  return g;
}

function spawnPlayerCar(){
  // remove existing if present
  if(player && player.parent) scene.remove(player);
  const sel = document.getElementById('carSelect').value;
  let color = 0xff4444;
  if(sel==='gtr') color = 0x2222ff;
  if(sel==='r8') color = 0x22aa22;
  if(sel==='supra') color = 0xffaa00;
  if(sel==='porsche') color = 0x44ff44;
  player = makeCarMesh(color, "PlayerCar");
  player.position.set(0,0.35, -10);
  player.userData.speed = 0;
  player.userData.dir = 0;
  scene.add(player);
  hud.status.textContent = "En parking";
  updateCameraFollow(true);
}

function resetPlayer(){
  if(!player) return;
  player.position.set(0,0.35,-10);
  player.userData.speed = 0;
  player.userData.dir = 0;
  hud.status.textContent = "Reset";
  updateCameraFollow(true);
}

function onWindowResize(){ camera.aspect = window.innerWidth/window.innerHeight; camera.updateProjectionMatrix(); renderer.setSize(window.innerWidth, window.innerHeight); }
function onKeyDown(e){ keyState[e.code] = true; if(e.code==='Space'){ keyState['Space']=true; } }
function onKeyUp(e){ keyState[e.code] = false; if(e.code==='Space'){ keyState['Space']=false; } }

function animate(){ requestAnimationFrame(animate); const dt = Math.min(0.05, clock.getDelta()); updatePhysics(dt); renderer.render(scene,camera); updateCameraFollow(); updateHUD(); }

function updatePhysics(dt){
  if(!player) return;
  // improved control logic:
  // ArrowUp => forward acceleration
  // ArrowDown => if speed > 0.5 then apply strong brake, else apply reverse acceleration
  const acc = 100; const brakeForce = 220; const reverseAcc = -60;
  let forwardInput = keyState['ArrowUp'] ? 1 : 0;
  let backInput = keyState['ArrowDown'] ? 1 : 0;
  // acceleration
  if(forwardInput){
    player.userData.speed += acc * dt;
  }
  // braking or reverse
  if(backInput){
    if(player.userData.speed > 0.6){
      // apply brake strong
      player.userData.speed -= brakeForce * dt;
    } else {
      // go into reverse
      player.userData.speed += reverseAcc * dt;
    }
  }
  // handbrake slows faster
  if(keyState['Space']){
    player.userData.speed *= Math.max(0, 1 - 4*dt);
  }
  // clamp speed
  player.userData.speed = Math.max(-40, Math.min(180, player.userData.speed));
  // steering
  let steer = 0;
  if(keyState['ArrowLeft']) steer = -1;
  if(keyState['ArrowRight']) steer = 1;
  // steering effectiveness depends on speed
  const steerEffect = 1.2 * (Math.abs(player.userData.speed)/80);
  player.userData.dir += steer * steerEffect * dt;
  // update position
  player.position.x += Math.sin(player.userData.dir) * player.userData.speed * dt;
  player.position.z += Math.cos(player.userData.dir) * player.userData.speed * dt;
  // small damping
  player.userData.speed *= 0.995;
  // keep inside bounds
  player.position.x = Math.max(-180, Math.min(180, player.position.x));
  player.position.z = Math.max(-120, Math.min(120, player.position.z));
  // simple collision with parked cars (push them a bit)
  for(let c of cars){
    if(c === player) continue;
    const d = c.position.distanceTo(player.position);
    if(d < 2.4){
      // push the other car slightly and reduce speed
      const dx = c.position.x - player.position.x; const dz = c.position.z - player.position.z;
      c.position.x += dx*0.05; c.position.z += dz*0.05;
      player.userData.speed *= 0.6;
      player.userData.damage = Math.min(100, (player.userData.damage||0) + 5);
    }
  }
}

function updateCameraFollow(force=false){
  if(!player) return;
  // third-person camera following behind the car
  const targetPos = new THREE.Vector3(player.position.x, player.position.y+2.2, player.position.z + 8);
  const camPos = new THREE.Vector3().lerpVectors(camera.position, targetPos, force?1:0.08);
  camera.position.copy(camPos);
  const lookAt = new THREE.Vector3(player.position.x, player.position.y+1, player.position.z);
  camera.lookAt(lookAt);
}

function updateHUD(){
  if(!player) return;
  hud.speed.textContent = Math.round(Math.abs(player.userData.speed));
  hud.tire.textContent = player.userData.tire || 'Slick';
}

